let circleX;
let circleY;
let windSpeed;
let windDirection;
function setup() {
  createCanvas(800, 500);
  background(200);
  circleX=random(20,780);
  circleY=-5;
  windSpeed=15;
  windDirection=0;
}

function draw() {
  background(200);
  Snowflake();
  circle(circleX,circleY,10);
  circleY+=5;

  if(windDirection==0){
    circleX+=windSpeed;
  }else if(windDirection==1){
    circleX-=windSpeed;
  }

  let direction=random();
  if(direction<=0.1){
    windDirection=1;
  }else if(direction>=0.9){
    windDirection=0;
  }

  if(circleX>805||circleX<-5){
    circleY=-5;
    circleX=random(20,780);
  }

  if(circleY>=505){
    circleY=-5;
    circleX=random(20,780);
  }
}

function Snowflake(){
  let snowflake=0;
  if(snowflake<10000){
    circle(random(1,800),random(1,500),10)
    snowflake++;
  }
}