function setup() {
  createCanvas(500, 500);
  background(0);
  stars();
  strokeWeight(0);
  colorMode(RGB);
  fill(140,30,148,255);
  circle(100,150,50);
  fill(176,130,22,255);
  circle(300,250,75);
  fill(204,255,255,255);
  triangle(175,300,180,305,175,310)
  triangle(50,305,175,300,175,310);
  fill(154,154,154,255);
  ellipse(215,305,50,30);
  triangle(180,300,215,305,180,310);
  quad(0,500,250,450,500,500,250,550)
  fill(255,255,51,255);
  circle(230,305,15);
}

function stars() {
  let cosmos = 0;
  fill(255,255,255);
  stroke(0);
  while (cosmos < 300) {
    cosmos++;
    circle(random(500),random(500),random(1,5))
  }
}